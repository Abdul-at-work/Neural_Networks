using the command: "python part3_1.py & python part3_2.py & python part3_3.py & python part3_4.py & python part3_5.py &
python part3_6.py & python part3_7.py & python part3_8.py & python part3_9.py & python part3_10.py"

this should create CSV files with mean accuracy scores for each model, it should also create plots for each model.

then use the command: "python final_model.py"

creates a csv file for for final model mean scores and training error plot

then use the command: "python confidence_interval.py"

should show the mean accuracy and confidence interval for each model.
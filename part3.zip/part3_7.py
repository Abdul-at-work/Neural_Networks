import torch
import torch.nn as nn
import numpy as np
import pickle
import matplotlib.pyplot as plt

class MultilayerPerceptron(nn.Module):
    def __init__(self):
        super().__init__()
        self.layer1 =torch.nn.Linear(784,512)
        self.layer2=torch.nn.Linear(512,10)
        

    def forward(self,X):
        activation_function = torch.nn.Sigmoid()
        hidden_layer_output= activation_function(self.layer1(X))
        output_layer = self.layer2(hidden_layer_output)
        return output_layer    
# we load all the datasets of Part 3
x_train, y_train = pickle.load(open("data/mnist_train.data", "rb"))
x_validation, y_validation = pickle.load(open("data/mnist_validation.data", "rb"))
x_test, y_test = pickle.load(open("data/mnist_test.data", "rb"))

x_train = x_train/255.0
x_train = x_train.astype(np.float32)

x_test = x_test / 255.0
x_test = x_test.astype(np.float32)

x_validation = x_validation/255.0
x_validation = x_validation.astype(np.float32)

# and converting them into Pytorch tensors in order to be able to work with Pytorch
x_train = torch.from_numpy(x_train)
y_train = torch.from_numpy(y_train).to(torch.long)

x_validation = torch.from_numpy(x_validation)
y_validation = torch.from_numpy(y_validation).to(torch.long)

x_test = torch.from_numpy(x_test)
y_test = torch.from_numpy(y_test).to(torch.long)


accuracy_array=[]
train_loss_array = np.zeros((80,10))
validation_loss_array = np.zeros((80,10))
nth_run=range(1,11)
for i in nth_run:
    model=MultilayerPerceptron()
    optimizer=torch.optim.Adam(model.parameters(),lr=0.01)
    loss=torch.nn.CrossEntropyLoss()
    softmax_function = torch.nn.Softmax(dim =1)
    epochs=80
    iteration_array = []
    for iteration in range(1,epochs+1):
        correct_train=0
        correct_validation=0
        iteration_array.append(iteration)
        optimizer.zero_grad()
        train_predictions=model(x_train)
        crossentropy_value= loss(train_predictions,y_train)
        probability_scores = softmax_function(train_predictions)
        train_predictions_classified=torch.argmax(probability_scores,axis=1)
        train_loss_array[iteration-1][i-1]=(crossentropy_value.item())
        crossentropy_value.backward()
        optimizer.step()
        with torch.no_grad():
            correct_train+=(train_predictions_classified==y_train).float().sum()
            train_accuracy = 100* correct_train/len(y_train)
            validation_predictions = model(x_validation)
            validation_crossentropy_loss = loss(validation_predictions,y_validation)
            probability_scores = softmax_function(validation_predictions)
            validation_predictions_classified=torch.argmax(probability_scores,axis=1)

        # Here you are expected to calculate the average/mean cross entropy loss for the validation datasets by using the validation dataset labels.

            validation_loss_array[iteration-1][i-1]=(validation_crossentropy_loss.item())

        # Similarly, here, you are expected to calculate the accuracy score on the validation dataset
            correct_validation+=(validation_predictions_classified==y_validation).float().sum()
            validation_accuracy = 100*correct_validation/len(y_validation)
    
        print("Run Number: %d Iteration : %d - Train Loss %.4f - Train Accuracy : %.2f - Validation Loss : %.4f Validation Accuracy : %.2f" % (i,iteration, crossentropy_value.item(), train_accuracy, validation_crossentropy_loss.item(), validation_accuracy))


# after completing the training, we calculate our network's accuracy score on the test dataset...
# Again, here we don't need to perform any gradient-related operations, so we are using torch.no_grad() function.
    with torch.no_grad():
        correct=0
        test_predictions = model(x_test)
    # Here you are expected to calculate the network accuracy score on the test dataset...
        probability_scores = softmax_function(test_predictions)
        test_predictions_classified=torch.argmax(probability_scores,axis=1)
        correct+=(test_predictions_classified==y_test).float().sum()
        test_accuracy = 100* correct/len(y_test)
        accuracy_array.append(test_accuracy)
        print("Test accuracy : %.2f" % (test_accuracy.item()))

np.savetxt("part3_7.csv", accuracy_array, delimiter=", ", fmt="% s")

# We plot the loss versus iteration graph for both datasets (training and validation)
plt.plot(iteration_array, (np.mean(train_loss_array,axis=1)).tolist(), label="Train Loss")
plt.plot(iteration_array, (np.mean(validation_loss_array,axis=1)).tolist(), label="Validation Loss")
plt.legend()
plt.savefig("part3_7.png")

    



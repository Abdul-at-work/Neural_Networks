import numpy as np
name="part3_"
csv_extension=".csv"
plot_extension="conplot.png"

num_input=range(1,11)

for i in num_input:
    data = np.loadtxt(name+str(i)+csv_extension)
    m=np.mean(data)
    s=np.std(data)
    print("mean for ",name+str(i)+csv_extension,":",m)
    lower_bound=m-1.96*(s/np.sqrt(10))
    upper_bound=m+1.96*(s/np.sqrt(10))
    print("confidence Interval (%.2f,%.2f)"%(lower_bound,upper_bound))

data = np.loadtxt("final.csv")
m=np.mean(data)
s=np.std(data)
print("mean for final model: ",m)
lower_bound=m-1.96*(s/np.sqrt(10))
upper_bound=m+1.96*(s/np.sqrt(10))
print("confidence interval (%.2f,%.2f)"%(lower_bound,upper_bound))